-- =====================================================
-- Migration 16: Harmony Map Domain Schema
--
-- Maps Equilibrium Canon metrics (E, S, H) onto
-- geographic scopes: person > city > state > country > continent > world
-- =====================================================

-- Core node table (cities, states, etc.)
CREATE TABLE IF NOT EXISTS harmony_nodes (
    node_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    scope TEXT NOT NULL,
    name TEXT NOT NULL,
    parent_node_id UUID REFERENCES harmony_nodes(node_id),
    geometry JSONB,
    population BIGINT,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indicator definitions (what we measure)
CREATE TABLE IF NOT EXISTS harmony_indicators (
    indicator_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    key TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    dimension TEXT NOT NULL,
    direction TEXT NOT NULL DEFAULT 'lower_is_better',
    normalization_method TEXT DEFAULT 'min_max',
    unit TEXT,
    description TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Raw indicator values per node per time window
CREATE TABLE IF NOT EXISTS harmony_indicator_values (
    value_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    node_id UUID NOT NULL REFERENCES harmony_nodes(node_id),
    indicator_id UUID NOT NULL REFERENCES harmony_indicators(indicator_id),
    time_window_start DATE NOT NULL,
    time_window_end DATE NOT NULL,
    raw_value REAL NOT NULL,
    normalized_value REAL,
    source_dataset TEXT,
    provenance JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(node_id, indicator_id, time_window_start)
);

-- Computed dimension and top-level scores
CREATE TABLE IF NOT EXISTS harmony_scores (
    score_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    node_id UUID NOT NULL REFERENCES harmony_nodes(node_id),
    time_window_start DATE NOT NULL,
    time_window_end DATE NOT NULL,
    balance REAL,
    flow REAL,
    compassion REAL,
    discernment REAL,
    care REAL,
    e_raw REAL,
    e_scaled REAL,
    awareness REAL,
    expression REAL,
    intent_coherence REAL,
    harmony REAL,
    computation_hash TEXT,
    weight_version INTEGER DEFAULT 1,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(node_id, time_window_start)
);

-- Weight configurations (versioned, editable)
CREATE TABLE IF NOT EXISTS harmony_weights (
    weight_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    version INTEGER NOT NULL,
    indicator_key TEXT NOT NULL,
    weight REAL NOT NULL DEFAULT 1.0,
    scope TEXT DEFAULT 'global',
    created_by TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(version, indicator_key, scope)
);

-- Normalization bounds (versioned)
CREATE TABLE IF NOT EXISTS harmony_normalization_bounds (
    bound_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    indicator_key TEXT NOT NULL,
    version INTEGER NOT NULL DEFAULT 1,
    min_value REAL NOT NULL,
    max_value REAL NOT NULL,
    scope TEXT DEFAULT 'global',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Scenarios (what-if sandbox)
CREATE TABLE IF NOT EXISTS harmony_scenarios (
    scenario_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    base_node_id UUID REFERENCES harmony_nodes(node_id),
    adjustments JSONB NOT NULL DEFAULT '{}',
    projected_scores JSONB,
    status TEXT DEFAULT 'draft',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Immutable audit log
CREATE TABLE IF NOT EXISTS harmony_audit_log (
    audit_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT,
    action TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id UUID,
    before_state JSONB,
    after_state JSONB,
    computation_hash TEXT,
    ts TIMESTAMPTZ DEFAULT NOW()
);

-- Data catalog (dataset metadata)
CREATE TABLE IF NOT EXISTS harmony_datasets (
    dataset_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    source_url TEXT,
    license TEXT,
    refresh_cadence TEXT,
    fields JSONB,
    last_refreshed TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Drift alerts
CREATE TABLE IF NOT EXISTS harmony_alerts (
    alert_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    node_id UUID NOT NULL REFERENCES harmony_nodes(node_id),
    indicator_key TEXT,
    alert_type TEXT NOT NULL,
    severity TEXT DEFAULT 'warning',
    message TEXT NOT NULL,
    details JSONB,
    acknowledged BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_harmony_nodes_scope ON harmony_nodes(scope);
CREATE INDEX IF NOT EXISTS idx_harmony_nodes_parent ON harmony_nodes(parent_node_id);
CREATE INDEX IF NOT EXISTS idx_harmony_values_node ON harmony_indicator_values(node_id);
CREATE INDEX IF NOT EXISTS idx_harmony_values_indicator ON harmony_indicator_values(indicator_id);
CREATE INDEX IF NOT EXISTS idx_harmony_scores_node ON harmony_scores(node_id);
CREATE INDEX IF NOT EXISTS idx_harmony_scores_time ON harmony_scores(time_window_start DESC);
CREATE INDEX IF NOT EXISTS idx_harmony_audit_ts ON harmony_audit_log(ts DESC);
CREATE INDEX IF NOT EXISTS idx_harmony_audit_entity ON harmony_audit_log(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_harmony_alerts_node ON harmony_alerts(node_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_harmony_scenarios_user ON harmony_scenarios(user_id);
