-- =====================================================
-- Migration 19: Add Oakland + Daily Analytics Snapshots
--
-- 1. Daily snapshot table for tracking city metric trends
-- 2. Oakland, CA as 6th pilot city with indicator data
-- =====================================================

-- ============================================================
-- 1. Daily Snapshot Table (for Analytics page)
-- ============================================================
CREATE TABLE IF NOT EXISTS harmony_daily_snapshots (
    snapshot_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    node_id UUID NOT NULL REFERENCES harmony_nodes(node_id),
    snapshot_date DATE NOT NULL,
    harmony REAL,
    e_raw REAL,
    e_scaled REAL,
    balance REAL,
    flow REAL,
    compassion REAL,
    discernment REAL,
    care REAL,
    awareness REAL,
    expression REAL,
    intent_coherence REAL,
    indicator_changes JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(node_id, snapshot_date)
);

CREATE INDEX IF NOT EXISTS idx_harmony_snapshots_node_date
    ON harmony_daily_snapshots(node_id, snapshot_date DESC);

-- ============================================================
-- 2. Seed Oakland Node
-- ============================================================
INSERT INTO harmony_nodes (node_id, scope, name, geometry, population, parent_node_id, metadata) VALUES
('b0000000-0000-0000-0000-000000000006', 'city', 'Oakland',
 '{"type":"Point","coordinates":[-122.2711,37.8044]}',
 433031, 'a0000000-0000-0000-0000-000000000001',
 '{"state":"CA","fips":"0653000"}')
ON CONFLICT DO NOTHING;

-- ============================================================
-- 3. Seed Oakland Indicator Values (2024 annual window)
-- ============================================================
-- Oakland profile: high crime, strong community orgs, port economy,
-- gentrification pressure, vibrant arts scene, good transit (BART)

INSERT INTO harmony_indicator_values (node_id, indicator_id, time_window_start, time_window_end, raw_value, source_dataset, provenance)
SELECT 'b0000000-0000-0000-0000-000000000006', indicator_id, '2024-01-01', '2024-12-31', v.raw_value, v.source, ('{"dataset":"' || v.source || '","year":2024}')::jsonb
FROM harmony_indicators hi
JOIN (VALUES
    ('violent_crime_rate', 1250.0, 'FBI UCR'),
    ('property_crime_rate', 5200.0, 'FBI UCR'),
    ('income_inequality_gini', 0.50, 'ACS'),
    ('homelessness_rate', 65.0, 'HUD PIT'),
    ('unemployment_rate', 5.5, 'BLS'),
    ('labor_participation', 64.0, 'BLS'),
    ('median_commute_time', 32.0, 'ACS'),
    ('transit_access_score', 58.0, 'AllTransit'),
    ('uninsured_rate', 7.8, 'ACS'),
    ('mental_health_providers', 200.0, 'HRSA'),
    ('food_insecurity_rate', 13.0, 'Feeding America'),
    ('eviction_rate', 3.2, 'Eviction Lab'),
    ('hs_graduation_rate', 74.0, 'NCES'),
    ('college_attainment', 38.0, 'ACS'),
    ('voter_turnout', 65.0, 'SoS'),
    ('library_access', 3.0, 'IMLS'),
    ('civic_engagement_index', 0.70, 'composite'),
    ('transparency_score', 0.68, 'open data audit'),
    ('arts_orgs_per_capita', 38.0, 'NEA'),
    ('protest_freedom_index', 0.82, 'ACLU')
) AS v(key, raw_value, source) ON hi.key = v.key
ON CONFLICT (node_id, indicator_id, time_window_start) DO NOTHING;
