-- Harmony Suggestions & Observer tables
-- Migration 20: Suggestions system + Observer federated learning for Harmony Map

-- ────────────────────────────────────────────────────
-- Suggestions — Oggy-generated improvement proposals
-- ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS harmony_suggestions (
    suggestion_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT NOT NULL,
    node_id UUID REFERENCES harmony_nodes(node_id),
    suggestion_type TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    payload JSONB NOT NULL DEFAULT '{}',
    status TEXT NOT NULL DEFAULT 'pending',
    source TEXT NOT NULL DEFAULT 'chat',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    resolved_at TIMESTAMPTZ,
    resolved_by TEXT,
    CONSTRAINT valid_suggestion_type CHECK (suggestion_type IN ('new_indicator', 'new_data_point', 'weight_adjustment', 'model_update')),
    CONSTRAINT valid_suggestion_status CHECK (status IN ('pending', 'accepted', 'rejected', 'expired'))
);

CREATE INDEX IF NOT EXISTS idx_harmony_suggestions_user ON harmony_suggestions(user_id, status);
CREATE INDEX IF NOT EXISTS idx_harmony_suggestions_node ON harmony_suggestions(node_id, status);

-- ────────────────────────────────────────────────────
-- Observer — Federated learning for Harmony Map
-- ────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS harmony_observer_config (
    user_id TEXT PRIMARY KEY,
    share_changes BOOLEAN NOT NULL DEFAULT FALSE,
    receive_harmony_packs BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS harmony_observer_packs (
    pack_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    version INTEGER NOT NULL DEFAULT 1,
    name TEXT NOT NULL,
    changes JSONB NOT NULL DEFAULT '[]'::jsonb,
    evidence JSONB NOT NULL DEFAULT '{}'::jsonb,
    impact_level TEXT NOT NULL DEFAULT 'low',
    status TEXT NOT NULL DEFAULT 'available',
    nodes_affected TEXT[] DEFAULT '{}',
    dimensions_affected TEXT[] DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    applied_at TIMESTAMPTZ,
    rolled_back_at TIMESTAMPTZ,
    CONSTRAINT valid_impact CHECK (impact_level IN ('low', 'medium', 'high')),
    CONSTRAINT valid_hpack_status CHECK (status IN ('available', 'applied', 'rolled_back', 'superseded'))
);

CREATE TABLE IF NOT EXISTS harmony_observer_job_log (
    job_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at TIMESTAMPTZ,
    status TEXT NOT NULL DEFAULT 'running',
    stats JSONB NOT NULL DEFAULT '{}'::jsonb,
    packs_generated INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS harmony_observer_pack_applications (
    application_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    pack_id UUID NOT NULL REFERENCES harmony_observer_packs(pack_id),
    user_id TEXT NOT NULL,
    action TEXT NOT NULL,
    changes_applied INTEGER DEFAULT 0,
    rollback_snapshot JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
