-- =====================================================
-- Migration 17: Harmony Map Seed Data
--
-- 5 pilot US cities with curated public indicator data
-- Cities: San Francisco, Detroit, Austin, Columbus, Portland
-- =====================================================

-- ============================================================
-- 1. Seed Nodes (5 cities + US parent)
-- ============================================================
INSERT INTO harmony_nodes (node_id, scope, name, geometry, population, metadata) VALUES
('a0000000-0000-0000-0000-000000000001', 'country', 'United States', '{"type":"Point","coordinates":[-98.5795,39.8283]}', 331900000, '{"iso":"US"}'),
('b0000000-0000-0000-0000-000000000001', 'city', 'San Francisco', '{"type":"Point","coordinates":[-122.4194,37.7749]}', 874961, '{"state":"CA","fips":"0667000"}'),
('b0000000-0000-0000-0000-000000000002', 'city', 'Detroit', '{"type":"Point","coordinates":[-83.0458,42.3314]}', 639111, '{"state":"MI","fips":"2622000"}'),
('b0000000-0000-0000-0000-000000000003', 'city', 'Austin', '{"type":"Point","coordinates":[-97.7431,30.2672]}', 979263, '{"state":"TX","fips":"4805000"}'),
('b0000000-0000-0000-0000-000000000004', 'city', 'Columbus', '{"type":"Point","coordinates":[-82.9988,39.9612]}', 905748, '{"state":"OH","fips":"3918000"}'),
('b0000000-0000-0000-0000-000000000005', 'city', 'Portland', '{"type":"Point","coordinates":[-122.6765,45.5152]}', 652503, '{"state":"OR","fips":"4159000"}')
ON CONFLICT DO NOTHING;

-- Set parent for cities
UPDATE harmony_nodes SET parent_node_id = 'a0000000-0000-0000-0000-000000000001'
WHERE scope = 'city' AND parent_node_id IS NULL;

-- ============================================================
-- 2. Seed Indicator Definitions
-- ============================================================
INSERT INTO harmony_indicators (key, name, dimension, direction, unit, description) VALUES
-- Balance indicators
('violent_crime_rate', 'Violent Crime Rate', 'balance', 'lower_is_better', 'per 100k', 'FBI UCR violent crimes per 100,000 residents'),
('property_crime_rate', 'Property Crime Rate', 'balance', 'lower_is_better', 'per 100k', 'FBI UCR property crimes per 100,000 residents'),
('income_inequality_gini', 'Income Inequality (Gini)', 'balance', 'lower_is_better', 'index', 'Gini coefficient of income inequality (0-1)'),
('homelessness_rate', 'Homelessness Rate', 'balance', 'lower_is_better', 'per 10k', 'HUD PIT count per 10,000 residents'),

-- Flow indicators
('unemployment_rate', 'Unemployment Rate', 'flow', 'lower_is_better', '%', 'BLS unemployment rate'),
('labor_participation', 'Labor Force Participation', 'flow', 'higher_is_better', '%', 'BLS labor force participation rate'),
('median_commute_time', 'Median Commute Time', 'flow', 'lower_is_better', 'minutes', 'ACS median commute time'),
('transit_access_score', 'Transit Access Score', 'flow', 'higher_is_better', 'score 0-100', 'AllTransit transit access score'),

-- Compassion indicators
('uninsured_rate', 'Uninsured Rate', 'compassion', 'lower_is_better', '%', 'ACS health insurance coverage gap'),
('mental_health_providers', 'Mental Health Providers', 'compassion', 'higher_is_better', 'per 100k', 'HRSA mental health provider ratio'),
('food_insecurity_rate', 'Food Insecurity Rate', 'compassion', 'lower_is_better', '%', 'Feeding America food insecurity rate'),
('eviction_rate', 'Eviction Rate', 'compassion', 'lower_is_better', '%', 'Eviction Lab filing rate'),

-- Discernment indicators
('hs_graduation_rate', 'HS Graduation Rate', 'discernment', 'higher_is_better', '%', 'NCES high school graduation rate'),
('college_attainment', 'College Attainment', 'discernment', 'higher_is_better', '%', 'ACS bachelor degree or higher rate'),
('voter_turnout', 'Voter Turnout', 'discernment', 'higher_is_better', '%', 'Recent general election voter turnout'),
('library_access', 'Library Access', 'discernment', 'higher_is_better', 'per 100k', 'Public libraries per 100,000 residents'),

-- Awareness indicators (for S = sqrt(A * X))
('civic_engagement_index', 'Civic Engagement Index', 'awareness', 'higher_is_better', 'score 0-1', 'Composite: volunteering, community org, town halls'),
('transparency_score', 'Government Transparency', 'awareness', 'higher_is_better', 'score 0-1', 'Open data portal quality + FOIA responsiveness'),

-- Expression indicators (for S = sqrt(A * X))
('arts_orgs_per_capita', 'Arts Organizations Per Capita', 'expression', 'higher_is_better', 'per 100k', 'NEA arts/culture nonprofits per 100k'),
('protest_freedom_index', 'Protest Freedom Index', 'expression', 'higher_is_better', 'score 0-1', 'ACLU civil liberties + protest permit accessibility')
ON CONFLICT (key) DO NOTHING;

-- ============================================================
-- 3. Seed Indicator Values (2024 annual window)
-- ============================================================

-- San Francisco (high-performing but with inequality/homelessness challenges)
INSERT INTO harmony_indicator_values (node_id, indicator_id, time_window_start, time_window_end, raw_value, source_dataset, provenance)
SELECT 'b0000000-0000-0000-0000-000000000001', indicator_id, '2024-01-01', '2024-12-31', v.raw_value, v.source, ('{"dataset":"' || v.source || '","year":2024}')::jsonb
FROM harmony_indicators hi
JOIN (VALUES
    ('violent_crime_rate', 670.0, 'FBI UCR'),
    ('property_crime_rate', 4500.0, 'FBI UCR'),
    ('income_inequality_gini', 0.52, 'ACS'),
    ('homelessness_rate', 90.0, 'HUD PIT'),
    ('unemployment_rate', 3.8, 'BLS'),
    ('labor_participation', 68.5, 'BLS'),
    ('median_commute_time', 33.0, 'ACS'),
    ('transit_access_score', 72.0, 'AllTransit'),
    ('uninsured_rate', 5.2, 'ACS'),
    ('mental_health_providers', 350.0, 'HRSA'),
    ('food_insecurity_rate', 9.5, 'Feeding America'),
    ('eviction_rate', 1.8, 'Eviction Lab'),
    ('hs_graduation_rate', 87.0, 'NCES'),
    ('college_attainment', 58.0, 'ACS'),
    ('voter_turnout', 72.0, 'SoS'),
    ('library_access', 3.5, 'IMLS'),
    ('civic_engagement_index', 0.72, 'composite'),
    ('transparency_score', 0.85, 'open data audit'),
    ('arts_orgs_per_capita', 45.0, 'NEA'),
    ('protest_freedom_index', 0.80, 'ACLU')
) AS v(key, raw_value, source) ON hi.key = v.key
ON CONFLICT (node_id, indicator_id, time_window_start) DO NOTHING;

-- Detroit (struggling city working toward recovery)
INSERT INTO harmony_indicator_values (node_id, indicator_id, time_window_start, time_window_end, raw_value, source_dataset, provenance)
SELECT 'b0000000-0000-0000-0000-000000000002', indicator_id, '2024-01-01', '2024-12-31', v.raw_value, v.source, ('{"dataset":"' || v.source || '","year":2024}')::jsonb
FROM harmony_indicators hi
JOIN (VALUES
    ('violent_crime_rate', 1965.0, 'FBI UCR'),
    ('property_crime_rate', 4200.0, 'FBI UCR'),
    ('income_inequality_gini', 0.49, 'ACS'),
    ('homelessness_rate', 25.0, 'HUD PIT'),
    ('unemployment_rate', 8.2, 'BLS'),
    ('labor_participation', 55.0, 'BLS'),
    ('median_commute_time', 27.0, 'ACS'),
    ('transit_access_score', 38.0, 'AllTransit'),
    ('uninsured_rate', 12.5, 'ACS'),
    ('mental_health_providers', 120.0, 'HRSA'),
    ('food_insecurity_rate', 22.0, 'Feeding America'),
    ('eviction_rate', 6.5, 'Eviction Lab'),
    ('hs_graduation_rate', 72.0, 'NCES'),
    ('college_attainment', 16.0, 'ACS'),
    ('voter_turnout', 48.0, 'SoS'),
    ('library_access', 2.0, 'IMLS'),
    ('civic_engagement_index', 0.40, 'composite'),
    ('transparency_score', 0.45, 'open data audit'),
    ('arts_orgs_per_capita', 18.0, 'NEA'),
    ('protest_freedom_index', 0.65, 'ACLU')
) AS v(key, raw_value, source) ON hi.key = v.key
ON CONFLICT (node_id, indicator_id, time_window_start) DO NOTHING;

-- Austin (high-performing, tech hub, growing fast)
INSERT INTO harmony_indicator_values (node_id, indicator_id, time_window_start, time_window_end, raw_value, source_dataset, provenance)
SELECT 'b0000000-0000-0000-0000-000000000003', indicator_id, '2024-01-01', '2024-12-31', v.raw_value, v.source, ('{"dataset":"' || v.source || '","year":2024}')::jsonb
FROM harmony_indicators hi
JOIN (VALUES
    ('violent_crime_rate', 380.0, 'FBI UCR'),
    ('property_crime_rate', 3800.0, 'FBI UCR'),
    ('income_inequality_gini', 0.46, 'ACS'),
    ('homelessness_rate', 30.0, 'HUD PIT'),
    ('unemployment_rate', 3.2, 'BLS'),
    ('labor_participation', 70.0, 'BLS'),
    ('median_commute_time', 26.0, 'ACS'),
    ('transit_access_score', 42.0, 'AllTransit'),
    ('uninsured_rate', 14.0, 'ACS'),
    ('mental_health_providers', 220.0, 'HRSA'),
    ('food_insecurity_rate', 12.0, 'Feeding America'),
    ('eviction_rate', 3.5, 'Eviction Lab'),
    ('hs_graduation_rate', 90.0, 'NCES'),
    ('college_attainment', 48.0, 'ACS'),
    ('voter_turnout', 58.0, 'SoS'),
    ('library_access', 2.8, 'IMLS'),
    ('civic_engagement_index', 0.62, 'composite'),
    ('transparency_score', 0.70, 'open data audit'),
    ('arts_orgs_per_capita', 35.0, 'NEA'),
    ('protest_freedom_index', 0.60, 'ACLU')
) AS v(key, raw_value, source) ON hi.key = v.key
ON CONFLICT (node_id, indicator_id, time_window_start) DO NOTHING;

-- Columbus (mid-range, steady Midwestern city)
INSERT INTO harmony_indicator_values (node_id, indicator_id, time_window_start, time_window_end, raw_value, source_dataset, provenance)
SELECT 'b0000000-0000-0000-0000-000000000004', indicator_id, '2024-01-01', '2024-12-31', v.raw_value, v.source, ('{"dataset":"' || v.source || '","year":2024}')::jsonb
FROM harmony_indicators hi
JOIN (VALUES
    ('violent_crime_rate', 580.0, 'FBI UCR'),
    ('property_crime_rate', 4100.0, 'FBI UCR'),
    ('income_inequality_gini', 0.44, 'ACS'),
    ('homelessness_rate', 18.0, 'HUD PIT'),
    ('unemployment_rate', 4.5, 'BLS'),
    ('labor_participation', 66.0, 'BLS'),
    ('median_commute_time', 23.0, 'ACS'),
    ('transit_access_score', 35.0, 'AllTransit'),
    ('uninsured_rate', 9.0, 'ACS'),
    ('mental_health_providers', 180.0, 'HRSA'),
    ('food_insecurity_rate', 14.0, 'Feeding America'),
    ('eviction_rate', 8.0, 'Eviction Lab'),
    ('hs_graduation_rate', 82.0, 'NCES'),
    ('college_attainment', 36.0, 'ACS'),
    ('voter_turnout', 55.0, 'SoS'),
    ('library_access', 3.2, 'IMLS'),
    ('civic_engagement_index', 0.55, 'composite'),
    ('transparency_score', 0.60, 'open data audit'),
    ('arts_orgs_per_capita', 22.0, 'NEA'),
    ('protest_freedom_index', 0.70, 'ACLU')
) AS v(key, raw_value, source) ON hi.key = v.key
ON CONFLICT (node_id, indicator_id, time_window_start) DO NOTHING;

-- Portland (mixed — progressive policies, some challenges)
INSERT INTO harmony_indicator_values (node_id, indicator_id, time_window_start, time_window_end, raw_value, source_dataset, provenance)
SELECT 'b0000000-0000-0000-0000-000000000005', indicator_id, '2024-01-01', '2024-12-31', v.raw_value, v.source, ('{"dataset":"' || v.source || '","year":2024}')::jsonb
FROM harmony_indicators hi
JOIN (VALUES
    ('violent_crime_rate', 490.0, 'FBI UCR'),
    ('property_crime_rate', 5800.0, 'FBI UCR'),
    ('income_inequality_gini', 0.45, 'ACS'),
    ('homelessness_rate', 55.0, 'HUD PIT'),
    ('unemployment_rate', 4.0, 'BLS'),
    ('labor_participation', 67.0, 'BLS'),
    ('median_commute_time', 26.0, 'ACS'),
    ('transit_access_score', 55.0, 'AllTransit'),
    ('uninsured_rate', 6.5, 'ACS'),
    ('mental_health_providers', 280.0, 'HRSA'),
    ('food_insecurity_rate', 11.0, 'Feeding America'),
    ('eviction_rate', 2.5, 'Eviction Lab'),
    ('hs_graduation_rate', 80.0, 'NCES'),
    ('college_attainment', 45.0, 'ACS'),
    ('voter_turnout', 68.0, 'SoS'),
    ('library_access', 4.0, 'IMLS'),
    ('civic_engagement_index', 0.68, 'composite'),
    ('transparency_score', 0.75, 'open data audit'),
    ('arts_orgs_per_capita', 40.0, 'NEA'),
    ('protest_freedom_index', 0.75, 'ACLU')
) AS v(key, raw_value, source) ON hi.key = v.key
ON CONFLICT (node_id, indicator_id, time_window_start) DO NOTHING;

-- ============================================================
-- 4. Seed Normalization Bounds (global, version 1)
-- ============================================================
INSERT INTO harmony_normalization_bounds (indicator_key, version, min_value, max_value, scope) VALUES
('violent_crime_rate', 1, 100, 2500, 'global'),
('property_crime_rate', 1, 1000, 7000, 'global'),
('income_inequality_gini', 1, 0.30, 0.60, 'global'),
('homelessness_rate', 1, 5, 100, 'global'),
('unemployment_rate', 1, 2.0, 12.0, 'global'),
('labor_participation', 1, 50.0, 80.0, 'global'),
('median_commute_time', 1, 15.0, 45.0, 'global'),
('transit_access_score', 1, 10.0, 90.0, 'global'),
('uninsured_rate', 1, 2.0, 20.0, 'global'),
('mental_health_providers', 1, 50.0, 500.0, 'global'),
('food_insecurity_rate', 1, 5.0, 30.0, 'global'),
('eviction_rate', 1, 0.5, 10.0, 'global'),
('hs_graduation_rate', 1, 60.0, 98.0, 'global'),
('college_attainment', 1, 10.0, 65.0, 'global'),
('voter_turnout', 1, 30.0, 80.0, 'global'),
('library_access', 1, 1.0, 6.0, 'global'),
('civic_engagement_index', 1, 0.20, 0.90, 'global'),
('transparency_score', 1, 0.20, 0.95, 'global'),
('arts_orgs_per_capita', 1, 5.0, 60.0, 'global'),
('protest_freedom_index', 1, 0.30, 0.95, 'global')
ON CONFLICT (indicator_key, version, scope) DO NOTHING;

-- ============================================================
-- 5. Seed Default Weights (version 1, equal weighting)
-- ============================================================
INSERT INTO harmony_weights (version, indicator_key, weight, scope, created_by) VALUES
(1, 'violent_crime_rate', 1.0, 'global', 'system'),
(1, 'property_crime_rate', 1.0, 'global', 'system'),
(1, 'income_inequality_gini', 1.0, 'global', 'system'),
(1, 'homelessness_rate', 1.0, 'global', 'system'),
(1, 'unemployment_rate', 1.0, 'global', 'system'),
(1, 'labor_participation', 1.0, 'global', 'system'),
(1, 'median_commute_time', 1.0, 'global', 'system'),
(1, 'transit_access_score', 1.0, 'global', 'system'),
(1, 'uninsured_rate', 1.0, 'global', 'system'),
(1, 'mental_health_providers', 1.0, 'global', 'system'),
(1, 'food_insecurity_rate', 1.0, 'global', 'system'),
(1, 'eviction_rate', 1.0, 'global', 'system'),
(1, 'hs_graduation_rate', 1.0, 'global', 'system'),
(1, 'college_attainment', 1.0, 'global', 'system'),
(1, 'voter_turnout', 1.0, 'global', 'system'),
(1, 'library_access', 1.0, 'global', 'system'),
(1, 'civic_engagement_index', 1.0, 'global', 'system'),
(1, 'transparency_score', 1.0, 'global', 'system'),
(1, 'arts_orgs_per_capita', 1.0, 'global', 'system'),
(1, 'protest_freedom_index', 1.0, 'global', 'system')
ON CONFLICT (version, indicator_key, scope) DO NOTHING;

-- ============================================================
-- 6. Seed Dataset Catalog
-- ============================================================
INSERT INTO harmony_datasets (name, source_url, license, refresh_cadence, fields) VALUES
('FBI Uniform Crime Reports', 'https://cde.ucr.cjis.gov/', 'Public Domain', 'yearly', '[{"field":"violent_crime_rate","type":"rate"},{"field":"property_crime_rate","type":"rate"}]'::jsonb),
('Bureau of Labor Statistics', 'https://www.bls.gov/lau/', 'Public Domain', 'monthly', '[{"field":"unemployment_rate","type":"percent"},{"field":"labor_participation","type":"percent"}]'::jsonb),
('American Community Survey (ACS)', 'https://www.census.gov/programs-surveys/acs', 'Public Domain', 'yearly', '[{"field":"income_inequality_gini","type":"index"},{"field":"uninsured_rate","type":"percent"},{"field":"college_attainment","type":"percent"},{"field":"median_commute_time","type":"minutes"}]'::jsonb),
('HUD Point-in-Time Count', 'https://www.huduser.gov/portal/datasets/ahar.html', 'Public Domain', 'yearly', '[{"field":"homelessness_rate","type":"rate"}]'::jsonb),
('HRSA Health Workforce', 'https://data.hrsa.gov/', 'Public Domain', 'yearly', '[{"field":"mental_health_providers","type":"rate"}]'::jsonb),
('Feeding America Map the Meal Gap', 'https://map.feedingamerica.org/', 'CC BY 4.0', 'yearly', '[{"field":"food_insecurity_rate","type":"percent"}]'::jsonb),
('Eviction Lab', 'https://evictionlab.org/', 'CC BY 4.0', 'yearly', '[{"field":"eviction_rate","type":"percent"}]'::jsonb),
('NCES Education Statistics', 'https://nces.ed.gov/', 'Public Domain', 'yearly', '[{"field":"hs_graduation_rate","type":"percent"}]'::jsonb)
ON CONFLICT (name) DO NOTHING;
