-- =====================================================
-- Migration 18: Fix duplicate normalization bounds and datasets
--
-- Root cause: harmony_normalization_bounds and harmony_datasets
-- lacked unique constraints, so every service restart re-inserted
-- seed data, causing N duplicates per row.
-- =====================================================

-- 1. Deduplicate harmony_normalization_bounds (keep oldest per key+version+scope)
DELETE FROM harmony_normalization_bounds
WHERE bound_id NOT IN (
    SELECT DISTINCT ON (indicator_key, version, scope) bound_id
    FROM harmony_normalization_bounds
    ORDER BY indicator_key, version, scope, created_at ASC
);

-- 2. Add unique constraint to prevent future duplicates
ALTER TABLE harmony_normalization_bounds
    ADD CONSTRAINT uq_bounds_key_version_scope UNIQUE (indicator_key, version, scope);

-- 3. Deduplicate harmony_datasets (keep oldest per name)
DELETE FROM harmony_datasets
WHERE dataset_id NOT IN (
    SELECT DISTINCT ON (name) dataset_id
    FROM harmony_datasets
    ORDER BY name, created_at ASC
);

-- 4. Add unique constraint to prevent future duplicates
ALTER TABLE harmony_datasets
    ADD CONSTRAINT uq_datasets_name UNIQUE (name);
