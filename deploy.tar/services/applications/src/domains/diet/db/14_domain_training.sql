-- Domain-Specific Training: Branded Foods + Domain Columns
-- Migration 14

-- Branded foods reference table for diet training ground truth
CREATE TABLE IF NOT EXISTS branded_foods (
    food_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    brand TEXT NOT NULL,
    product TEXT NOT NULL,
    serving_size TEXT,
    calories REAL,
    protein_g REAL,
    carbs_g REAL,
    fat_g REAL,
    fiber_g REAL,
    sugar_g REAL,
    sodium_mg REAL,
    category TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_branded_foods_brand ON branded_foods(LOWER(brand));
CREATE INDEX IF NOT EXISTS idx_branded_foods_category ON branded_foods(category);

-- Add domain column to benchmark tables for domain-specific training
ALTER TABLE sealed_benchmarks ADD COLUMN IF NOT EXISTS domain TEXT DEFAULT 'payments';
ALTER TABLE sealed_benchmark_results ADD COLUMN IF NOT EXISTS domain TEXT DEFAULT 'payments';
ALTER TABLE sealed_benchmark_scenarios ADD COLUMN IF NOT EXISTS domain TEXT DEFAULT 'payments';

-- Add domain to continuous learning state for per-domain progression
-- First drop the existing PK constraint, then re-add with domain
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'continuous_learning_state' AND column_name = 'domain'
    ) THEN
        ALTER TABLE continuous_learning_state ADD COLUMN domain TEXT DEFAULT 'payments';
        ALTER TABLE continuous_learning_state DROP CONSTRAINT IF EXISTS continuous_learning_state_pkey;
        ALTER TABLE continuous_learning_state ADD PRIMARY KEY (user_id, domain);
    END IF;
END $$;

-- ============================================================
-- Seed branded foods (~75 popular items)
-- ============================================================

-- Protein Shakes
INSERT INTO branded_foods (brand, product, serving_size, calories, protein_g, carbs_g, fat_g, fiber_g, sugar_g, sodium_mg, category) VALUES
('Core Power', 'Elite Strawberry Protein Shake', '14 fl oz', 230, 42, 13, 3, 0, 7, 340, 'protein_shake'),
('Core Power', 'Elite Chocolate Protein Shake', '14 fl oz', 230, 42, 13, 3.5, 1, 7, 390, 'protein_shake'),
('Core Power', 'Elite Vanilla Protein Shake', '14 fl oz', 230, 42, 13, 3, 0, 7, 340, 'protein_shake'),
('Core Power', 'Chocolate Protein Shake', '11.5 fl oz', 170, 26, 10, 3.5, 1, 5, 280, 'protein_shake'),
('Premier Protein', 'Chocolate Shake', '11 fl oz', 160, 30, 5, 3, 1, 1, 320, 'protein_shake'),
('Premier Protein', 'Vanilla Shake', '11 fl oz', 160, 30, 5, 3, 1, 1, 290, 'protein_shake'),
('Premier Protein', 'Caramel Shake', '11 fl oz', 160, 30, 5, 3, 1, 1, 340, 'protein_shake'),
('Fairlife', 'Core Power Chocolate', '14 fl oz', 170, 26, 10, 3.5, 1, 5, 280, 'protein_shake'),
('Muscle Milk', 'Genuine Chocolate Shake', '14 fl oz', 230, 25, 12, 9, 2, 4, 270, 'protein_shake'),
('Muscle Milk', 'Genuine Vanilla Creme Shake', '14 fl oz', 230, 25, 12, 9, 2, 4, 290, 'protein_shake'),
('Optimum Nutrition', 'Gold Standard Whey Double Rich Chocolate', '1 scoop (31g)', 120, 24, 3, 1.5, 0, 1, 130, 'protein_shake'),
('Optimum Nutrition', 'Gold Standard Whey Vanilla Ice Cream', '1 scoop (31g)', 120, 24, 4, 1, 0, 1, 130, 'protein_shake'),
('Ghost', 'Whey Protein Cereal Milk', '1 scoop (36g)', 130, 25, 5, 1.5, 0, 2, 180, 'protein_shake'),
('Dymatize', 'ISO100 Fruity Pebbles', '1 scoop (32g)', 120, 25, 2, 0.5, 0, 1, 160, 'protein_shake')
ON CONFLICT DO NOTHING;

-- Energy Drinks
INSERT INTO branded_foods (brand, product, serving_size, calories, protein_g, carbs_g, fat_g, fiber_g, sugar_g, sodium_mg, category) VALUES
('Celsius', 'Sparkling Orange', '12 fl oz', 10, 0, 2, 0, 0, 0, 0, 'energy_drink'),
('Celsius', 'Sparkling Wild Berry', '12 fl oz', 10, 0, 2, 0, 0, 0, 0, 'energy_drink'),
('Celsius', 'Sparkling Peach Vibe', '12 fl oz', 10, 0, 2, 0, 0, 0, 0, 'energy_drink'),
('Celsius', 'Sparkling Watermelon', '12 fl oz', 10, 0, 2, 0, 0, 0, 0, 'energy_drink'),
('Red Bull', 'Original Energy Drink', '8.4 fl oz', 110, 0, 28, 0, 0, 27, 105, 'energy_drink'),
('Red Bull', 'Sugar Free', '8.4 fl oz', 5, 0, 0, 0, 0, 0, 105, 'energy_drink'),
('Monster', 'Original Energy Drink', '16 fl oz', 210, 0, 54, 0, 0, 54, 370, 'energy_drink'),
('Monster', 'Ultra Zero Sugar', '16 fl oz', 0, 0, 2, 0, 0, 0, 370, 'energy_drink'),
('Bang', 'Rainbow Unicorn', '16 fl oz', 0, 0, 0, 0, 0, 0, 40, 'energy_drink'),
('C4', 'Original Smart Energy Cherry Limeade', '16 fl oz', 0, 0, 1, 0, 0, 0, 0, 'energy_drink'),
('Ghost', 'Energy Drink Sour Patch Kids Blue Raspberry', '16 fl oz', 5, 0, 2, 0, 0, 0, 50, 'energy_drink'),
('Alani Nu', 'Energy Drink Cosmic Stardust', '12 fl oz', 10, 0, 1, 0, 0, 0, 70, 'energy_drink')
ON CONFLICT DO NOTHING;

-- Snack / Protein Bars
INSERT INTO branded_foods (brand, product, serving_size, calories, protein_g, carbs_g, fat_g, fiber_g, sugar_g, sodium_mg, category) VALUES
('Quest', 'Chocolate Chip Cookie Dough Bar', '1 bar (60g)', 190, 21, 22, 8, 14, 1, 280, 'snack_bar'),
('Quest', 'Cookies and Cream Bar', '1 bar (60g)', 190, 21, 22, 7, 14, 1, 310, 'snack_bar'),
('RXBAR', 'Chocolate Sea Salt', '1 bar (52g)', 210, 12, 24, 9, 5, 13, 260, 'snack_bar'),
('RXBAR', 'Blueberry', '1 bar (52g)', 210, 12, 24, 9, 5, 15, 160, 'snack_bar'),
('KIND', 'Dark Chocolate Nuts & Sea Salt', '1 bar (40g)', 200, 6, 17, 15, 3, 5, 125, 'snack_bar'),
('KIND', 'Peanut Butter Dark Chocolate', '1 bar (40g)', 200, 7, 17, 14, 3, 5, 140, 'snack_bar'),
('Clif Bar', 'Chocolate Chip', '1 bar (68g)', 250, 10, 45, 5, 4, 21, 150, 'snack_bar'),
('Clif Bar', 'Crunchy Peanut Butter', '1 bar (68g)', 250, 11, 42, 6, 4, 21, 250, 'snack_bar'),
('Nature Valley', 'Oats N Honey Crunchy Granola Bar', '2 bars (42g)', 190, 3, 29, 7, 2, 11, 180, 'snack_bar'),
('LARABAR', 'Peanut Butter Chocolate Chip', '1 bar (45g)', 220, 7, 24, 12, 3, 16, 95, 'snack_bar'),
('Built Bar', 'Puff Churro', '1 bar (46g)', 130, 17, 15, 3, 4, 5, 170, 'snack_bar'),
('ONE', 'Birthday Cake Protein Bar', '1 bar (60g)', 220, 20, 24, 8, 0, 1, 190, 'snack_bar')
ON CONFLICT DO NOTHING;

-- Fast Food
INSERT INTO branded_foods (brand, product, serving_size, calories, protein_g, carbs_g, fat_g, fiber_g, sugar_g, sodium_mg, category) VALUES
('Chipotle', 'Chicken Burrito Bowl (rice, beans, salsa, cheese, guac)', '1 bowl', 1005, 55, 90, 44, 15, 4, 2050, 'fast_food'),
('Chipotle', 'Steak Burrito Bowl (rice, beans, salsa, cheese, guac)', '1 bowl', 1035, 55, 90, 47, 15, 4, 2080, 'fast_food'),
('Chipotle', 'Chicken Burrito (flour tortilla, rice, beans, salsa, cheese)', '1 burrito', 1045, 57, 120, 36, 12, 5, 2310, 'fast_food'),
('Chick-fil-A', 'Original Chicken Sandwich', '1 sandwich', 440, 28, 40, 18, 1, 6, 1400, 'fast_food'),
('Chick-fil-A', 'Spicy Chicken Sandwich', '1 sandwich', 450, 28, 41, 19, 2, 6, 1620, 'fast_food'),
('Chick-fil-A', 'Nuggets 8-count', '8 nuggets', 250, 27, 11, 11, 0, 1, 1090, 'fast_food'),
('Chick-fil-A', 'Waffle Fries Medium', '1 medium', 420, 5, 45, 24, 5, 1, 290, 'fast_food'),
('McDonalds', 'Big Mac', '1 sandwich', 550, 25, 45, 30, 3, 9, 1010, 'fast_food'),
('McDonalds', 'McChicken', '1 sandwich', 400, 14, 40, 21, 1, 5, 780, 'fast_food'),
('McDonalds', 'Medium Fries', '1 medium', 320, 5, 43, 15, 4, 0, 260, 'fast_food'),
('McDonalds', 'Quarter Pounder with Cheese', '1 sandwich', 520, 30, 42, 26, 2, 10, 1140, 'fast_food'),
('Subway', '6 inch Turkey Breast Sub', '1 sub', 270, 18, 36, 4, 3, 5, 760, 'fast_food'),
('Subway', '6 inch Italian BMT Sub', '1 sub', 370, 17, 37, 16, 2, 5, 1330, 'fast_food'),
('Taco Bell', 'Crunchy Taco', '1 taco', 170, 8, 13, 10, 3, 1, 310, 'fast_food'),
('Taco Bell', 'Bean Burrito', '1 burrito', 380, 14, 55, 11, 8, 3, 1060, 'fast_food'),
('Panda Express', 'Orange Chicken', '1 entree', 490, 25, 51, 23, 1, 19, 820, 'fast_food'),
('Panda Express', 'Fried Rice', '1 side', 520, 11, 68, 22, 2, 3, 850, 'fast_food')
ON CONFLICT DO NOTHING;

-- Coffee & Drinks
INSERT INTO branded_foods (brand, product, serving_size, calories, protein_g, carbs_g, fat_g, fiber_g, sugar_g, sodium_mg, category) VALUES
('Starbucks', 'Grande Caffe Latte (2% Milk)', '16 fl oz', 190, 13, 19, 7, 0, 17, 170, 'coffee'),
('Starbucks', 'Grande Caramel Frappuccino', '16 fl oz', 370, 5, 57, 14, 0, 54, 250, 'coffee'),
('Starbucks', 'Grande Vanilla Sweet Cream Cold Brew', '16 fl oz', 200, 3, 28, 10, 0, 26, 30, 'coffee'),
('Starbucks', 'Grande Pike Place Brewed Coffee (Black)', '16 fl oz', 5, 1, 0, 0, 0, 0, 10, 'coffee'),
('Dunkin', 'Medium Iced Coffee (cream + sugar)', '24 fl oz', 170, 2, 30, 6, 0, 28, 70, 'coffee'),
('Coca-Cola', 'Classic', '12 fl oz can', 140, 0, 39, 0, 0, 39, 45, 'soft_drink'),
('Coca-Cola', 'Zero Sugar', '12 fl oz can', 0, 0, 0, 0, 0, 0, 40, 'soft_drink'),
('Pepsi', 'Original', '12 fl oz can', 150, 0, 41, 0, 0, 41, 30, 'soft_drink'),
('Gatorade', 'Thirst Quencher Lemon Lime', '20 fl oz', 140, 0, 36, 0, 0, 34, 270, 'soft_drink'),
('Gatorade', 'Zero Glacier Cherry', '20 fl oz', 0, 0, 1, 0, 0, 0, 270, 'soft_drink'),
('Fairlife', 'Whole Milk', '1 cup (240ml)', 150, 13, 12, 8, 0, 6, 150, 'dairy'),
('Fairlife', '2% Reduced Fat Milk', '1 cup (240ml)', 120, 13, 12, 4.5, 0, 6, 150, 'dairy'),
('Chobani', 'Greek Yogurt Plain Nonfat', '1 container (150g)', 90, 16, 6, 0, 0, 4, 55, 'dairy'),
('Chobani', 'Greek Yogurt Strawberry', '1 container (150g)', 120, 12, 15, 0, 0, 11, 50, 'dairy')
ON CONFLICT DO NOTHING;
