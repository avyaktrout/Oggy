-- =====================================================
-- Migration 15: Relax CHECK constraints for multi-domain support
--
-- The original constraints in 01_payments_init.sql and
-- 008_sealed_benchmarks.sql were payments-specific.
-- Now that diet and general domains share these tables,
-- the constraints are too restrictive:
--   - sealed_benchmark_scenarios.valid_category: diet stores JSON nutrition,
--     general stores JSON evaluation criteria
--   - app_events.valid_entity_type: diet uses 'diet_training'
--   - app_events.valid_action: diet uses 'nutrition_estimation'
-- =====================================================

-- Drop payments-only category constraint on benchmark scenarios
ALTER TABLE sealed_benchmark_scenarios DROP CONSTRAINT IF EXISTS valid_category;

-- Drop payments-only constraints on app_events
ALTER TABLE app_events DROP CONSTRAINT IF EXISTS valid_entity_type;
ALTER TABLE app_events DROP CONSTRAINT IF EXISTS valid_action;
