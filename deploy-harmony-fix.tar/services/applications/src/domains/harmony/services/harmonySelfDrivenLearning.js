/**
 * Harmony Self-Driven Learning
 *
 * Training questions test Oggy on:
 * - Identifying missing indicators for a city
 * - Suggesting appropriate weights
 * - Predicting score impact of dimension changes
 * - Recommending data sources for uncovered indicators
 */

const { v4: uuidv4 } = require('uuid');
const { query } = require('../../../shared/utils/db');
const logger = require('../../../shared/utils/logger');
const providerResolver = require('../../../shared/providers/providerResolver');
const harmonySuggestionService = require('./harmonySuggestionService');

const instances = new Map();

class HarmonySelfDrivenLearning {
    constructor() {
        this.isRunning = false;
        this.interval = null;
        this.userId = null;
        this.sessionStats = { questionsAsked: 0, correct: 0, incorrect: 0 };
    }

    async start(userId, options = {}) {
        if (this.isRunning) return { status: 'already_running' };
        this.isRunning = true;
        this.userId = userId;
        // Preserve cumulative stats across stop/restart (e.g. benchmark pause/resume)
        if (!this.sessionStats || !this.sessionStats.questionsAsked) {
            this.sessionStats = { questionsAsked: 0, correct: 0, incorrect: 0 };
        }

        // Accept CLL-standard options: { interval (ms), practiceCount, enabled }
        const intervalMs = options.interval || (options.intervalMinutes || 2) * 60 * 1000;
        const attemptsPerSession = options.practiceCount || options.attemptsPerSession || 3;

        this.interval = setInterval(() => {
            this.runLearningSession(attemptsPerSession).catch(err => {
                logger.error('Harmony SDL session error', { error: err.message, userId });
            });
        }, intervalMs);

        // Run first session immediately
        await this.runLearningSession(attemptsPerSession);
        return { status: 'started', intervalMs, attemptsPerSession };
    }

    stop() {
        if (this.interval) clearInterval(this.interval);
        this.interval = null;
        this.isRunning = false;
        return { status: 'stopped', stats: { ...this.sessionStats } };
    }

    getStats() {
        const total = this.sessionStats.questionsAsked;
        const correct = this.sessionStats.correct;
        return {
            total_attempts: total,
            correct: correct,
            incorrect: this.sessionStats.incorrect,
            accuracy: total > 0
                ? (correct / total * 100).toFixed(1) + '%'
                : '0%',
            is_running: this.isRunning
        };
    }

    async runLearningSession(attempts = 3) {
        for (let i = 0; i < attempts; i++) {
            try {
                await this.practiceHarmonyQuestion();
            } catch (err) {
                logger.error('Harmony SDL practice error', { error: err.message, attempt: i });
            }
        }
    }

    async practiceHarmonyQuestion() {
        const traceId = uuidv4();
        const questionType = this._selectQuestionType();
        const assessment = await this._generateAssessment(questionType);
        if (!assessment) return;

        // Get Oggy's answer
        const oggyAnswer = await this._getOggyAnswer(assessment);

        // Evaluate the answer
        const evaluation = await this._evaluateAnswer(assessment, oggyAnswer);

        this.sessionStats.questionsAsked++;
        if (evaluation.correct) {
            this.sessionStats.correct++;
        } else {
            this.sessionStats.incorrect++;
        }

        // Update memory
        await this._updateMemory(traceId, assessment, oggyAnswer, evaluation);

        return {
            correct: evaluation.correct,
            questionType,
            assessment: assessment.question,
            expectedAnswer: assessment.expectedAnswer,
            oggyAnswer: oggyAnswer,
            score: evaluation.score,
            trace_id: traceId,
        };
    }

    _selectQuestionType() {
        const r = Math.random();
        if (r < 0.25) return 'missing_indicator';
        if (r < 0.50) return 'weight_suggestion';
        if (r < 0.75) return 'score_prediction';
        return 'data_source_recommendation';
    }

    async _generateAssessment(questionType) {
        try {
            // Load current state for context
            const nodes = await query(`
                SELECT n.name, n.scope, s.harmony, s.e_scaled, s.intent_coherence,
                       s.balance, s.flow, s.care, s.awareness, s.expression
                FROM harmony_nodes n
                LEFT JOIN harmony_scores s ON s.node_id = n.node_id
                WHERE n.scope = 'city'
                ORDER BY RANDOM() LIMIT 3
            `);

            const indicators = await query(`
                SELECT key, name, dimension, unit, direction FROM harmony_indicators LIMIT 30
            `);

            const cityContext = nodes.rows.map(n =>
                `${n.name}: H=${n.harmony || '?'}, E=${n.e_scaled || '?'}, S=${n.intent_coherence || '?'}, B=${n.balance || '?'}, F=${n.flow || '?'}, C=${n.care || '?'}, A=${n.awareness || '?'}, X=${n.expression || '?'}`
            ).join('\n');

            const indicatorList = indicators.rows.map(i => `${i.key} (${i.dimension}, ${i.direction})`).join(', ');
            const targetCity = nodes.rows[0]?.name || 'San Francisco';

            const prompts = {
                missing_indicator: {
                    question: `For ${targetCity}, which important wellbeing indicator is likely MISSING from the current set? Current indicators: ${indicatorList}. City scores: ${cityContext}. Name one specific missing indicator, which dimension it belongs to, and why it matters.`,
                    evaluationCriteria: 'Must name a plausible, specific indicator not in the current set, assign correct dimension, and give valid reasoning',
                },
                weight_suggestion: {
                    question: `Given these city scores:\n${cityContext}\nAnd indicators: ${indicatorList}\nSuggest a weight adjustment for ONE indicator that would better capture the wellbeing reality of ${targetCity}. Specify the indicator key, current approximate weight, suggested new weight (0-5 scale), and reasoning.`,
                    evaluationCriteria: 'Must reference an existing indicator, suggest a reasonable weight, and provide contextual reasoning',
                },
                score_prediction: {
                    question: `If ${targetCity}'s violent crime rate dropped by 30%, predict the approximate change in: Balance (B), Equilibrium (E), and Harmony (H) scores. Current scores: ${cityContext}. Show your reasoning with the formula chain.`,
                    evaluationCriteria: 'Must show correct formula chain (crime → Balance → E → H), directionally correct predictions, and reasonable magnitude estimates',
                },
                data_source_recommendation: {
                    question: `For ${targetCity}, recommend a specific publicly available data source that could improve the accuracy of the Harmony Map. Specify: source name, URL or organization, which indicators it would inform, update frequency, and data quality considerations.`,
                    evaluationCriteria: 'Must name a real, publicly accessible data source with plausible coverage and relevance',
                },
            };

            const prompt = prompts[questionType];
            return {
                question: prompt.question,
                evaluationCriteria: prompt.evaluationCriteria,
                questionType,
                targetCity,
                context: { cityContext, indicatorList },
            };
        } catch (err) {
            logger.error('Harmony SDL assessment generation failed', { error: err.message });
            return null;
        }
    }

    async _getOggyAnswer(assessment) {
        try {
            const resolved = await providerResolver.getAdapter(this.userId, 'oggy');
            const messages = [
                { role: 'system', content: 'You are Oggy, an expert on the Harmony Map wellbeing framework. The Harmony Map uses the Equilibrium Canon: H = sqrt(E * S), where E = (B*F*C)^(1/3) and S = sqrt(A*X). B=Balance, F=Flow, C=Care (Compassion*Discernment), A=Awareness, X=Expression. Answer precisely and concisely.' },
                { role: 'user', content: assessment.question },
            ];
            const response = await resolved.adapter.chatCompletion({
                model: resolved.model,
                messages,
                temperature: 0.4,
                max_tokens: 500,
            });
            return response.text || '';
        } catch (err) {
            logger.error('Harmony SDL Oggy answer failed', { error: err.message });
            return '';
        }
    }

    async _evaluateAnswer(assessment, oggyAnswer) {
        // Score threshold: answers scoring >= 3 out of 5 are considered correct
        // (matches general domain's approach for open-ended questions)
        const CORRECT_THRESHOLD = 3;

        try {
            const resolved = await providerResolver.getAdapter(this.userId, 'base');
            const messages = [
                { role: 'system', content: `You are an impartial judge evaluating an AI assistant's response about a city wellbeing framework.
Rate the response on a scale of 1-5:
  1 = Completely wrong or irrelevant
  2 = Partially relevant but major issues
  3 = Adequate — addresses the question with reasonable content
  4 = Good — well-structured, accurate, and insightful
  5 = Excellent — thorough, creative, and demonstrates deep understanding
Return ONLY valid JSON: { "score": <1-5>, "feedback": "..." }` },
                { role: 'user', content: `Question: ${assessment.question}\n\nEvaluation Criteria: ${assessment.evaluationCriteria}\n\nAnswer to evaluate:\n${oggyAnswer}\n\nReturn JSON only.` },
            ];
            const response = await resolved.adapter.chatCompletion({
                model: resolved.model,
                messages,
                temperature: 0.2,
                max_tokens: 300,
            });
            const text = response.text || '';
            const json = text.match(/\{[\s\S]*\}/);
            if (json) {
                const parsed = JSON.parse(json[0]);
                const score = parsed.score || 0;
                return {
                    correct: score >= CORRECT_THRESHOLD,
                    score,
                    feedback: parsed.feedback || ''
                };
            }
            return { correct: false, score: 0, feedback: 'Could not parse evaluation' };
        } catch (err) {
            logger.error('Harmony SDL evaluation failed', { error: err.message });
            return { correct: false, score: 0, feedback: err.message };
        }
    }

    async _updateMemory(traceId, assessment, answer, evaluation) {
        try {
            const memoryHost = process.env.MEMORY_SERVICE_URL || 'http://memory-service:3000';
            const delta = evaluation.correct ? 0.1 : -0.15;

            await fetch(`${memoryHost}/utility/update`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    user_id: this.userId,
                    trace_id: traceId,
                    utility_weight_delta: delta,
                    domain: 'harmony',
                    metadata: {
                        question_type: assessment.questionType,
                        correct: evaluation.correct,
                        score: evaluation.score,
                    },
                }),
            });

            // If correct and high quality (score 4+), store domain knowledge
            if (evaluation.correct && evaluation.score >= 4) {
                await fetch(`${memoryHost}/cards`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        user_id: this.userId,
                        domain: 'harmony',
                        content: `[${assessment.questionType}] Q: ${assessment.question.substring(0, 200)} A: ${answer.substring(0, 300)}`,
                        source_type: 'training',
                        trace_id: traceId,
                    }),
                });
            }
        } catch (err) {
            logger.error('Harmony SDL memory update failed', { error: err.message });
        }
    }
}

function getInstance(userId) {
    if (!instances.has(userId)) {
        const inst = new HarmonySelfDrivenLearning();
        inst.userId = userId;
        instances.set(userId, inst);
    }
    return instances.get(userId);
}

module.exports = { getInstance };
